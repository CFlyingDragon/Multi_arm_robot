# 文件内容介绍
urdf存储原始的机器人模型
robot存储加入传感器配置的模型文件，用于单臂物理仿真
robots存储用于多机器人物理仿真的模型文件
curdf用于实际控制

#关节名称
由于历史问题，所以关节名称统一为
[Joint1,Joint2,Joint3,Joint4,Joint5,Joint6,Joint7]
